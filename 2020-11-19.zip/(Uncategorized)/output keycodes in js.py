function setupKeyLogger() {
         document.onkeydown = function(e) {
           console.log(e);
         }
}