// Credit: github.com/danthareja

function doGet(request) {

  // ID of Google Spreadsheet
  var json = getNotesAndFormulas(request.parameter.id);

  return ContentService.createTextOutput(JSON.stringify(cache))
  .setMimeType(ContentService.MimeType.JSON);
}

function getNotesAndFormulas(spreadsheetId) {
  return SpreadsheetApp
  .openById(spreadsheetId)
  .getSheets()
  .reduce(function(cache, sheet) {

    var sheetData = cache[sheet.getName()] = {};
    var range = sheet.getDataRange();

    sheetData.range = range.getA1Notation();
    sheetData.notes = range.getNotes();
    sheetData.formulas = range.getFormulas();

    return cache;
  }, { spreadsheetId: spreadsheetId });
}