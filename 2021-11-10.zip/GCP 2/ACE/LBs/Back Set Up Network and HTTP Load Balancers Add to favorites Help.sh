# 1
# set default zone for all resources
gcloud config set compute/zone us-central1-a

# set default region for all resources
gcloud config set compute/region us-central1

# 2.A
# create new vm in default zone w/ same tag
gcloud compute instances create www1 \
  --image-family debian-9 \
  --image-project debian-cloud \
  --zone us-central1-a \
  --tags network-lb-tag \
  --metadata startup-script="#! /bin/bash
    sudo apt-get update
    sudo apt-get install apache2 -y
    sudo service apache2 restart
    echo '<!doctype html><html><body><h1>www1</h1></body></html>' | tee /var/www/html/index.html"
    
# 2.b 
# create firewall rule to allow external traffic to vm instances
gcloud compute firewall-rules create www-firewall-network-lb \
    --target-tags network-lb-tag --allow tcp:80
    
# 2.c Run the following to list your instances. You'll see their IP addresses in the EXTERNAL_IP column:
gcloud compute instances list

# 2.d Verify that each instance is running with curl, replacing [IP_ADDRESS] with the IP address for each of your VMs:
curl http://[IP_ADDRESS]

# Task 3: Configure the load balancing service
# 3.a Create a static external IP address for your load balancer:
gcloud compute addresses create network-lb-ip-1 \
 --region us-central1
 
 # 3.b Add a legacy HTTP health check resource:
 gcloud compute http-health-checks create basic-check
 
 # 3.c Add a target pool in the same region as your instances. Run the following to create the target pool and use the health check, which is required for the service to function:
 
gcloud compute target-pools create www-pool \
    --region us-central1 --http-health-check basic-check
    
# 3.d add instances to the pool
gcloud compute target-pools add-instances www-pool \
    --instances www1,www2,www3
    
    # Task 4: Sending traffic to your instances
    # Enter the following command to view the external IP address of the www-rule forwarding rule used by the load balancer:
    gcloud compute forwarding-rules describe www-rule --region us-central1
    
# Use curl command to access the external IP address, replacing IP_ADDRESS with an external IP address from the previous command:
while true; do curl -m1 IP_ADDRESS; done

# Task 5: Create an HTTP load balancer
# HTTP(S) Load Balancing is implemented on Google Front End (GFE). GFEs are distributed globally and operate together using Google's global network and control plane. You can configure URL rules to route some URLs to one set of instances and route other URLs to other instances. Requests are always routed to the instance group that is closest to the user, if that group has enough capacity and is appropriate for the request. If the closest group does not have enough capacity, the request is sent to the closest group that does have capacity.

# To set up a load balancer with a Compute Engine backend, your VMs need to be in an instance group. The managed instance group provides VMs running the backend servers of an external HTTP load balancer. backends serve their own hostnames.
# 5.a First, create the load balancer template:
gcloud compute instance-templates create lb-backend-template \
   --region=us-central1 \
   --network=default \
   --subnet=default \
   --tags=allow-health-check \
   --image-family=debian-9 \
   --image-project=debian-cloud \
   --metadata=startup-script='#! /bin/bash
     apt-get update
     apt-get install apache2 -y
     a2ensite default-ssl
     a2enmod ssl
     vm_hostname="$(curl -H "Metadata-Flavor:Google" \
     http://169.254.169.254/computeMetadata/v1/instance/name)"
     echo "Page served from: $vm_hostname" | \
     tee /var/www/html/index.html
     systemctl restart apache2'
     
# 5.b Create a managed instance group based on the template:
gcloud compute instance-groups managed create lb-backend-group \
   --template=lb-backend-template --size=2 --zone=us-central1-a
   
# 5.c Create the fw-allow-health-check firewall rule. This is an ingress rule that allows traffic from the Google Cloud health checking systems (130.211.0.0/22 and 35.191.0.0/16). This lab uses the target tag allow-health-check to identify the VMs.
gcloud compute firewall-rules create fw-allow-health-check \
    --network=default \
    --action=allow \
    --direction=ingress \
    --source-ranges=130.211.0.0/22,35.191.0.0/16 \
    --target-tags=allow-health-check \
    --rules=tcp:80
    
# 5.d Now that the instances are up and running, set up a global static external IP address that your customers use to reach your load balancer.
gcloud compute addresses create lb-ipv4-1 \
    --ip-version=IPV4 \
    --global
    
    # Note the IPv4 address that was reserved:
gcloud compute addresses describe lb-ipv4-1 \
    --format="get(address)" \
    --global

