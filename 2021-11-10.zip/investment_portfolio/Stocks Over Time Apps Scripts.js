// robinHood = 13, K4:M16
// scotTrade = 2, V4:X5
// tD = 9, AG4:AI12
// eTrade = 15, AR4:AT18 


//Lookup ticker symbol using Yahoo's web service (Called by each Account Function)
 
function lookupTicker(symbol) {
  //var symbol = "SPY" //Uncomment to test this function
  Logger.log(SpreadsheetApp.getActiveSheet().getName());
  var url = 'http://finance.yahoo.com/webservice/v1/symbols/'
    + symbol
    + '/quote?format=json';
  //Logger.log(url);
  var response = UrlFetchApp.fetch(url);
  var json = response.getContentText();
  var data = JSON.parse(json);
  Logger.log (data);
  //Logger.log(data.list.resources[0].resource.fields.symbol);
  //Logger.log(data.list.resources[0].resource.fields.price);
  return data.list.resources[0].resource.fields.price;
  
}


//Function to collect Values from Account Table and pass to lookupTicker function

//FIELDS TO ADJUST:
// 1) Function name
// 2) var tcount = number of tickers in account
// 3) var account = string of account name
// 4) var source = range in sheet to pull
// 5) var wsheet to write results in

function robinHood() {
  //Number of Stocks in account and name
  var tcount = 13;
  //Full array including stock name, sum column and account name
  var fullArray = tcount + 3;
  var account = "Robinhood";
  //Obtain values from spreadsheet
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName("Accounts");
  var wsheet = ss.getSheetByName("rh_History");
  var source = sheet.getRange("K4:M16");
  var values = source.getValues();
  Logger.log(values)
  var result = new Array(fullArray);
  result[0] = new Date();
  
  //for loop to parse each stock ticker and retrieve the current value from lookupTicker function
  for(var i=0; i<tcount; i++){
    var price = lookupTicker(values[i][0]);
    //Result written in [i+3] since the date, account total and name are written in first three fields
    //Subtract value of stock at time of purchase
    result[i+3] = (price * values[i][1]) - (values[i][2] * values[i][1]); 
  }
  
  //for loop to sum each ticker value, starts at 3 since the date, account total and name are written in first three fields
  //adjusted end range of loop for same reason
  var sum = 0;
  for(var i=3; i<=tcount+2; i++){
  sum = sum + result[i];
  Logger.log(sum)  
  }
  
  //add the sum and account name into result array 
  result[1] = account;
  result[2] = sum;

//Write final result to sheet  
wsheet.appendRow(result);
  
}; //End of Account Function ------------------------------------------------


//Function to collect Values from Account Table and pass to lookupTicker function 

//FIELDS TO ADJUST:
// 1) Function name
// 2) var tcount = number of tickers in account
// 3) var account = string of account name
// 4) var source = range in sheet to pull
// 5) var wsheet to write results in

function scotTrade() {
  //Number of Stocks in account and name
  var tcount = 2;
  //Full array including stock name, sum column and account name
  var fullArray = tcount + 3;
  var account = "Scottrade";
  //Obtain values from spreadsheet
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName("Accounts");
  var wsheet = ss.getSheetByName("sT_History");
  var source = sheet.getRange("V4:X5");
  var values = source.getValues();
  Logger.log(values)
  var result = new Array(fullArray);
  result[0] = new Date();
  
  //for loop to parse each stock ticker and retrieve the current value from lookupTicker function
  for(var i=0; i<tcount; i++){
    var price = lookupTicker(values[i][0]);
    //Result written in [i+3] since the date, account total and name are written in first three fields
    //Subtract value of stock at time of purchase
    result[i+3] = (price * values[i][1]) - (values[i][2] * values[i][1]); 
  }
  
  //for loop to sum each ticker value, starts at 3 since the date, account total and name are written in first three fields
  //adjusted end range of loop for same reason
  var sum = 0;
  for(var i=3; i<=tcount+2; i++){
  sum = sum + result[i];
  Logger.log(sum)  
  }
  
  //add the sum and account name into result array 
  result[1] = account;
  result[2] = sum;

//Write final result to sheet  
wsheet.appendRow(result);
  
}; //End of Account Function ------------------------------------------------


//Function to collect Values from Account Table and pass to lookupTicker function

//FIELDS TO ADJUST:
// 1) Function name
// 2) var tcount = number of tickers in account
// 3) var account = string of account name
// 4) var source = range in sheet to pull
// 5) var wsheet to write results in

function tD() {
  //Number of Stocks in account and name
  var tcount = 9;
  //Full array including stock name, sum column and account name
  var fullArray = tcount + 3;
  var account = "TDA";
  //Obtain values from spreadsheet
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName("Accounts");
  var wsheet = ss.getSheetByName("tD_History");
  var source = sheet.getRange("AG4:AI12");
  var values = source.getValues();
  Logger.log(values)
  var result = new Array(fullArray);
  result[0] = new Date();
  
  //for loop to parse each stock ticker and retrieve the current value from lookupTicker function
  for(var i=0; i<tcount; i++){
    var price = lookupTicker(values[i][0]);
    //Result written in [i+3] since the date, account total and name are written in first three fields
    //Subtract value of stock at time of purchase
    result[i+3] = (price * values[i][1]) - (values[i][2] * values[i][1]);  
  }
  
  //for loop to sum each ticker value, starts at 3 since the date, account total and name are written in first three fields
  //adjusted end range of loop for same reason
  var sum = 0;
  for(var i=3; i<=tcount+2; i++){
  sum = sum + result[i];
  Logger.log(sum)  
  }
  
  //add the sum and account name into result array 
  result[1] = account;
  result[2] = sum;

//Write final result to sheet  
wsheet.appendRow(result);
  
}; //End of Account Function ------------------------------------------------


//Function to collect Values from Account Table and pass to lookupTicker function

//FIELDS TO ADJUST:
// 1) Function name
// 2) var tcount = number of tickers in account
// 3) var account = string of account name
// 4) var source = range in sheet to pull
// 5) var wsheet to write results in

function eTrade() {
  //Number of Stocks in account and name
  var tcount = 15;
  //Full array including stock name, sum column and account name
  var fullArray = tcount + 3;
  var account = "eTrade";
  //Obtain values from spreadsheet
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName("Accounts");
  var wsheet = ss.getSheetByName("eT_History");
  var source = sheet.getRange("AR4:AT18");
  var values = source.getValues();
  Logger.log(values)
  var result = new Array(fullArray);
  result[0] = new Date();
  
  //for loop to parse each stock ticker and retrieve the current value from lookupTicker function
  for(var i=0; i<tcount; i++){
    var price = lookupTicker(values[i][0]);
    //Result written in [i+3] since the date, account total and name are written in first three fields
    //Subtract value of stock at time of purchase
    result[i+3] = (price * values[i][1]) - (values[i][2] * values[i][1]);  
  }
  
  //for loop to sum each ticker value, starts at 3 since the date, account total and name are written in first three fields
  //adjusted end range of loop for same reason
  var sum = 0;
  for(var i=3; i<=tcount+2; i++){
  sum = sum + result[i];
  Logger.log(sum)  
  }
  
  //add the sum and account name into result array 
  result[1] = account;
  result[2] = sum;

//Write final result to sheet  
wsheet.appendRow(result);
  
}; //End of Account Function ------------------------------------------------